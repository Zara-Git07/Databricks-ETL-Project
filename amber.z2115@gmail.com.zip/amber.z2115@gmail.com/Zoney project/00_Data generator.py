# Databricks notebook source
import pandas as pd
import random

customers = []

for i in range(1,1001):
    customers.append([
        i,
        f"Customer_{i}",
        random.choice(["TX","CA","FL"]),
        random.choice(["Fleet","Individual"])
    ])

df = pd.DataFrame(
    customers,
    columns=[
        "customer_id",
        "customer_name",
        "state",
        "customer_type"
    ]
)

spark_df = spark.createDataFrame(df)

display(spark_df)

# COMMAND ----------

display(spark_df)