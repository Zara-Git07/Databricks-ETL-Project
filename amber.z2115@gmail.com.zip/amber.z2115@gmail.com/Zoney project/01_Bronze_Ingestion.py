# Databricks notebook source
print("hello")

# COMMAND ----------

print("Zoney Project Started")

# COMMAND ----------

spark.range(10).show()

# COMMAND ----------

spark
